#pragma once

#include <string>
#include <array>
#include <inttypes.h>
#include <algorithm>

#include "binarytree.h"
#include "frequency_table.h"

using namespace std;

using CodePair = pair<uint8_t, string>;
using CodesTable = vector<CodePair>;

class Huffman
{
public:

	bool compress(string initial, const string compressed_filename, const string freq_filename);
private:
	void pack(const string bitstr, ofstream& fout);
	string findCode(const CodesTable& codes_table, uint8_t symb);
	int comressToFile(const CodesTable& codes_table, const string compressed_filename, string initial);
	bool freqToFile(const FreqTable& table, const string freq_filename, uint8_t add_bits);
	FreqTable createFreqTable(string str);
	void sortFreqTable(FreqTable& table);
	BinaryTree *buildTree(const FreqTable& freq_table);
	BinaryTreeNode* mergeNodes(BinaryTreeNode *left_node, BinaryTreeNode *right_node);
	CodesTable buildCodesTable(BinaryTree *head);
	void treeSearch(BinaryTreeNode* node);
	vector<BinaryTreeNode*> copy(u_int64_t from, uint64_t to, vector<BinaryTreeNode*> source);
	vector<BinaryTreeNode*> sortBuffer(vector<BinaryTreeNode*> buffer);
};

